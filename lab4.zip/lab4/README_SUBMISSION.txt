Lab4 - ROS Source Code Submission (Stable Tracking Version)

Source: Lab4_30s_20261026_013717.tar(1).gz

Main modified components:
- planner_pkg/src/simple_traj_planner.cpp (Part 0: hover at first waypoint)
- trajectory_generation_pkg/src/trajectory_generation_node.cpp (Parts 1.1-1.3)
- planner_pkg/launch/ and trajectory_generation_pkg/launch/ (controller gains and launch settings)
- controller_pkg/ (geometric controller and configuration)

Additional ROS-related dependencies and tesse-ros-bridge source are retained
for reference. The precompiled Unity simulator is intentionally excluded.
The code targets Ubuntu 20.04 with ROS Noetic and requires a configured
ROS/catkin environment and the separately supplied Unity simulator.

Configuration in this submitted code:
- v_max = 8.0, a_max = 4.0
- base_scale = 0.44, tail_multiplier = 1.40, slow_segments = 3
- desired state publication rate = 50 Hz

rviz_drone_race.txt contains the two user-provided video/rosbag links.
Please verify public access to both links before submitting.

This archive has been organized from the original source files; code was not
modified or recompiled during packaging.
